## Archive Structure
- Crest
- Dreams
- Rituals
- Memory Logs
- Alignment Architecture